code里是代码

请运行`main.py`

归结原理的实现在`Resolution_v1.py`

三个文本文件是测试案例
