1. **lab_v2_main.py**是执行程序的主函数，实现查询最短路径和清空日记的功能。
2. **Romania_path.py**实现了一个Romania类，调用其中的format_input(城市名1，城市名2)即可得到最短路径结果。
3. **Romania.txt**是读取文件内容，**Romania_diary.txt**是日记记录文件。
4. **实验1.md**是实验报告。